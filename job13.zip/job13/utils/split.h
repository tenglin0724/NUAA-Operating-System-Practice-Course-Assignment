#ifndef _UTILS_SPLIT_H
#define _UTILS_SPLIT_H

extern int split_string(char *string, char *delim, char *word_table[]);

#endif
