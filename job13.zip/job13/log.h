#ifndef _UXFS_TRACE_H
#define _UXFS_TRACE_H

extern int log_on;
extern void log_printf(char *fmt, ...);

#endif
