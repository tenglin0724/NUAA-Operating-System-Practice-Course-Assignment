#ifndef _DUMP_H
#define _DUMP_H

extern void dump_uxfs(int argc, char *argv[]);

#endif
