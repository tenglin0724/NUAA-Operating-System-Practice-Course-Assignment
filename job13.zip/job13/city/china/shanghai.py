print('shanghai')
