print('beijing')
