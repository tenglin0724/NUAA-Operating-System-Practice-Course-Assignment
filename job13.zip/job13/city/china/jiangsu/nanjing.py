print('nanjing')
