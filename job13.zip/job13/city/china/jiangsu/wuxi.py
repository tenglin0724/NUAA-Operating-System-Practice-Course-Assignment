print('wuxi')
