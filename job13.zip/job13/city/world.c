char *string = "world";
