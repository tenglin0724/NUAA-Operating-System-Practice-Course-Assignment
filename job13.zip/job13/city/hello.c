char *string = "hello";
